from aurora.fractal import Unit
from aurora.atom import Network
from aurora.paths import Memory, evolve

# Un tensor usado cierra su propia relación y habilita por primera vez las aristas.
witness = Unit.leaf()
Network(witness.gates).apply(
    [(g.i, 1) for g in witness.gates] +
    [(g.k, 1) for g in witness.gates] +
    [(g.o, 1) for g in witness.gates] +
    [(g.r, 1) for g in witness.gates] +
    [(g.e, 0) for g in witness.gates])

root = Unit.grow(1)
target = root.children[0]
Network(tuple(g for u in root.walk() for g in u.gates)).apply(
    [(g.i, 1) for g in target.gates] +
    [(g.k, 1) for g in target.gates])
memory = Memory()
print('Sin memoria:', evolve(root, target, memory))
memory.observe(('estructura', 'coherencia', 'organizacion'), witness)
print('Con testigo:', evolve(root, target, memory))
print('Prioridad observada:', memory.options(())[0].uses)
