# Aurora — Integración causal unificada (núcleo de referencia)

## Implementado

- Un **tipo de átomo TriGate**, una misma ley `solve()` a toda profundidad.
- `Unit.join()` compone unidades con caras DS, DE, DO y referencias a las celdas originales.
- `Network` propaga solamente relaciones afectadas por cambios de celda, **sin agenda por escala**.
- `Experience.receive()` habilita exclusivamente aristas históricamente observadas: una arista inexistente es imposible, no poco prioritaria. El testigo se conserva como restricciones **inmutables**, sin depender de futuras mutaciones de otra celda.
- Las alternativas se recorren por uso y recencia, con rollback ante contradicciones.
- `Evolution` reutiliza **la misma red causal** para entrada, encaje, propagación y selección, sin separar un motor local de uno global.
- Sin continuación viable: `inviable`; si sigue E=2 y existe exploración aplazada por presupuesto: `carry`; la selección local refuerza solo el camino usado.

## Demostraciones

```bash
python demo_unified.py
python -m unittest discover -p 'test*.py' -q
```

1. Entrada observada habilita camino y produce cierre local y aprendizaje de prioridad.
2. Mismo camino sin restricciones suficientes es inviable: no se inventa una solución.
3. Restricciones de la cúspide pueden cerrarla mientras unidades inferiores siguen abiertas. No hay etapas inferiores/ superiores.

## Límites que impiden declarar completa Aurora

1. La evidencia que se registra en memoria aún recibe desde fuera un recorrido `path`; todavía no surge enteramente de relaciones y celdas de la propia red.
2. `Experience` utiliza un índice Python; aún no es una memoria representada íntegramente mediante átomos fractales.
3. `Unit.join()` conserva una representación simplificada: la semántica definitiva de DO, organización/iteración y de las semillas solapadas de 39 trits sigue sin estar reproducida formalmente.
4. `locally_closed()` usa el criterio del prototipo y **no certifica** toda la coherencia superior ni la legitimidad del Output externo del libro. Por ello los estados son `local_closed`, no `globally_legitimate`.
5. La cola en Python simula activación causal; es determinista en orden de ejecución, aunque no introduce preferencia semántica por la altura. Para concurrencia real se necesitaría arbitraje transaccional.
6. Una contradicción en memoria con un mismo prefijo y etiqueta actualmente se rechaza en lugar de almacenar múltiples testimonios; hay que representar alternativas si se requieren.

**No se ha sustituido todavía la implementación histórica v41 con equivalencia completa.** Esta entrega integra las partes verificables en un único ciclo compacto y expone sin disimulo las diferencias pendientes.
