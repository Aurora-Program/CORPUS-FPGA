import unittest
from aurora.fractal import Unit, example


class Recursion(unittest.TestCase):
    def test_scaling(self):
        for depth, units in [(0,1),(1,4),(2,13),(3,40)]:
            root=Unit.grow(depth)
            self.assertEqual(len(tuple(root.walk())),units)
            self.assertEqual(len(root.network().atoms),3*units)
            self.assertEqual(len(root.faces),3)
            self.assertTrue(all(len(face)==3 for face in root.faces))

    def test_identity_and_rotation(self):
        root=Unit.grow(1)
        for j,gate in enumerate(root.gates):
            self.assertIs(gate.i, root.children[j].ds[j])
            self.assertIs(gate.k, root.children[(j+1)%3].de[j])
            self.assertIs(gate.o, root.children[(j+2)%3].do[j])

    def test_reuse_emergent_unit(self):
        a,b,c,d,e= (Unit.leaf() for _ in range(5))
        emergent=Unit.join(a,b,c)
        upper=Unit.join(emergent,d,e)
        self.assertIs(upper.gates[0].i, emergent.ds[0])
        self.assertEqual(len(upper.network().atoms),21)

    def test_bidirectional_constraint(self):
        root=Unit.grow(1)
        net=root.network()
        child=root.children[0]
        self.assertIs(root.gates[0].i,child.ds[0])
        net.apply(((root.gates[0].i,1),))
        self.assertEqual(child.ds[0].value,1)

    def test_conflict_rollback(self):
        root=Unit.grow(1)
        net=root.network()
        cell=root.children[0].ds[0]
        net.apply(((cell,1),))
        before={c:c.value for a in net.atoms for c in a.cells}
        with self.assertRaises(ValueError):
            net.apply(((cell,0),))
        self.assertEqual(before,{c:c.value for a in net.atoms for c in a.cells})

    def test_example(self):
        info=example()
        self.assertEqual(info['units'],13)
        self.assertEqual(info['atoms'],39)

if __name__=='__main__': unittest.main()

class EmergentFeedback(unittest.TestCase):
    def test_upper_coherence_restricts_lower_organization(self):
        root=Unit.grow(1)
        a,b,c=root.children
        net=root.network()
        net.apply(((a.ds[0],1),(b.de[0],0),(root.ds[0],1),(root.de[0],0)))
        self.assertEqual(c.do[0].value,1)
        self.assertIs(c.do[0],root.gates[0].o)
