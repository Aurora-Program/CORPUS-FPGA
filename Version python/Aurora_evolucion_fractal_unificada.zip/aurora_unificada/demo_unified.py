from aurora.fractal import Unit
from aurora.evolution import Evolution
from aurora.atom import Network


def tensor():
    t = Unit.leaf()
    Network(t.gates).apply([(g.i,1) for g in t.gates]+[(g.k,1) for g in t.gates]+[(g.o,1) for g in t.gates]+[(g.r,1) for g in t.gates]+[(g.e,0) for g in t.gates])
    return t

root=Unit.grow(1)
eng=Evolution(root)
goal=root.children[0]
eng.input(tensor(),('direccion','coherencia','organizacion'),[(g.i,1) for g in goal.gates]+[(g.k,1) for g in goal.gates])
print('Cierre por memoria:',eng.settle(goal))

root2=Unit.grow(1)
eng2=Evolution(root2)
eng2.input(tensor(),('direccion','coherencia','organizacion'))
print('Cierre sin contexto:',eng2.settle(root2.children[0]))
root3=Unit.grow(1)
eng3=Evolution(root3)
eng3.net.apply([(g.i,1) for g in root3.gates]+[(g.k,1) for g in root3.gates]+[(g.o,1) for g in root3.gates]+[(g.r,1) for g in root3.gates]+[(g.e,0) for g in root3.gates])
print('Superior cerrado primero:', root3.state, 'inferiores:', [u.state for u in root3.children])
