"""Unidades informacionales autosimilares: tres caras, una sola ley TriGate.

Cada cara es una tripleta de celdas. Una unidad compuesta usa EXACTAMENTE
el mismo tipo de unidad que una hoja; las referencias preservan identidad.
La tercera entrada NO constituye aún una semántica completa de DO.
"""
from dataclasses import dataclass
from .atom import Atom, Cell, Network


@dataclass(eq=False)
class Unit:
    gates: tuple[Atom, Atom, Atom]
    children: tuple['Unit', ...] = ()

    @classmethod
    def leaf(cls):
        return cls(tuple(Atom() for _ in range(3)))

    @classmethod
    def join(cls, a: 'Unit', b: 'Unit', c: 'Unit'):
        """Emergencia de un nivel: 3 unidades -> 1 unidad *idéntica*.

        Cada subrelación toma un componente de las tres caras de sus hijas.
        Rotación cíclica: ninguna hija ocupa siempre el mismo papel.
        """
        children = (a, b, c)
        gates = []
        for j in range(3):
            # Permutar los participantes sin transformar/copiar las celdas.
            x, y, z = (children[(j + offset) % 3] for offset in range(3))
            gates.append(Atom(i=x.ds[j], k=y.de[j], o=z.do[j]))
        return cls(tuple(gates), children)

    @classmethod
    def grow(cls, depth: int):
        if depth < 0: raise ValueError('negative depth')
        if depth == 0: return cls.leaf()
        return cls.join(*(cls.grow(depth - 1) for _ in range(3)))

    @property
    def ds(self) -> tuple[Cell, Cell, Cell]:
        return tuple(g.r for g in self.gates)

    @property
    def de(self) -> tuple[Cell, Cell, Cell]:
        return tuple(g.e for g in self.gates)

    @property
    def do(self) -> tuple[Cell, Cell, Cell]:
        return tuple(g.o for g in self.gates)

    @property
    def faces(self): return (self.ds, self.de, self.do)

    @property
    def state(self):
        return tuple(tuple(c.value for c in face) for face in self.faces)

    def walk(self):
        yield self
        for child in self.children:
            yield from child.walk()

    def network(self):
        return Network(gate for unit in self.walk() for gate in unit.gates)


def example():
    root = Unit.grow(2)
    net = root.network()
    leaves = [unit for unit in root.walk() if not unit.children]
    # Introducimos evidencia compatible, sin fijar R/E artificialmente.
    constraints = [(g.i, 1) for u in leaves for g in u.gates]
    constraints += [(g.k, 1) for u in leaves for g in u.gates]
    constraints += [(g.o, 0) for u in leaves for g in u.gates]
    activations = net.apply(constraints)
    return {'units': len(tuple(root.walk())), 'atoms': len(net.atoms),
            'activations': activations, 'summit': root.state}


if __name__ == '__main__':
    print(example())
