"""Celdas compartidas y propagación causal de una relación TriGate."""
from collections import defaultdict, deque
from dataclasses import dataclass, field
from .trigate import solve, CONFLICT


@dataclass(eq=False)
class Cell:
    value: int = 2

    def set(self, value):
        if type(value) is not int or value not in (0, 1, 2):
            raise ValueError('trit inválido')
        if value == 2:
            return False  # indeterminado: nunca borra evidencia
        if self.value != 2 and self.value != value:
            raise ValueError('contradicción')
        change = self.value != value
        self.value = value
        return change


@dataclass(eq=False)
class Atom:
    """La misma relación TriGate para cualquier posición o nivel."""
    i: Cell = field(default_factory=Cell)
    k: Cell = field(default_factory=Cell)
    o: Cell = field(default_factory=Cell)
    r: Cell = field(default_factory=Cell)
    e: Cell = field(default_factory=Cell)
    allowed: int = 255

    @property
    def cells(self):
        return self.i, self.k, self.o, self.r, self.e

    def evolve(self):
        resolution = solve(*(cell.value for cell in self.cells), allowed=self.allowed)
        if resolution.status == CONFLICT:
            raise ValueError('TriGate incompatible')
        values = list(resolution.values)
        # El solver ya proporciona la máscara de realizaciones compatibles.
        # Si TODAS coinciden en una entrada abierta, esa entrada está forzada.
        # No deducimos R/E aquí: conservamos su política original de cierre.
        possibilities = [i for i in range(8) if resolution.support & (1 << i)]
        for pos, shift in enumerate((2, 1, 0)):
            if values[pos] == 2:
                choices = {(i >> shift) & 1 for i in possibilities}
                if len(choices) == 1:
                    values[pos] = choices.pop()
        return tuple(cell for cell, value in zip(self.cells, values)
                     if cell.set(value))


class Network:
    """Propagación causal local sobre átomos con identidad de celda compartida.

    Un único planificador de referencia para Python; no forma parte de la ley
    ternaria ni decide valores. Puede traducirse a eventos hardware.
    """
    def __init__(self, atoms):
        self.atoms = tuple(dict.fromkeys(atoms))
        self.dependents = defaultdict(list)
        for atom in self.atoms:
            for cell in set(atom.cells):
                self.dependents[cell].append(atom)
        self.pending = deque()
        self.scheduled = set()
        self.activations = 0
        self.enqueue(self.atoms)

    def enqueue(self, atoms):
        for atom in atoms:
            if atom not in self.scheduled:
                self.pending.append(atom)
                self.scheduled.add(atom)

    def constrain(self, cell, value):
        """Una evidencia externa activa exactamente sus relaciones vecinas."""
        if cell.set(value):
            self.enqueue(self.dependents[cell])

    def apply(self, constraints, budget=100000):
        """Aplica frontera + propagación como UNA transacción reversible.

        Los pares son (Cell, trit); no requieren nombres de roles ni niveles.
        """
        snapshot = {cell: cell.value for atom in self.atoms for cell in atom.cells}
        queue_before = tuple(self.pending)
        scheduled_before = set(self.scheduled)
        activations_before = self.activations
        try:
            for cell, value in constraints:
                if cell not in snapshot:
                    raise ValueError('celda no conectada a la red')
                self.constrain(cell, value)
            return self.propagate(budget)
        except (ValueError, RuntimeError):
            for cell, value in snapshot.items():
                cell.value = value
            self.pending = deque(queue_before)
            self.scheduled = scheduled_before
            self.activations = activations_before
            raise

    def propagate(self, budget=100000):
        """Resuelve eventos como transacción: ningún conflicto deja medias escrituras.

        La transacción pertenece al simulador Python, no a la ley TriGate.
        """
        snapshot = {cell: cell.value for atom in self.atoms for cell in atom.cells}
        queue_before = tuple(self.pending)
        scheduled_before = set(self.scheduled)
        steps = 0
        try:
            while self.pending:
                if steps >= budget:
                    raise RuntimeError('presupuesto agotado; no se declara cierre')
                atom = self.pending.popleft()
                self.scheduled.remove(atom)
                steps += 1
                changed = atom.evolve()
                for cell in changed:
                    self.enqueue(self.dependents[cell])
        except (ValueError, RuntimeError):
            for cell, value in snapshot.items():
                cell.value = value
            self.pending = deque(queue_before)
            self.scheduled = scheduled_before
            raise
        self.activations += steps
        return steps


