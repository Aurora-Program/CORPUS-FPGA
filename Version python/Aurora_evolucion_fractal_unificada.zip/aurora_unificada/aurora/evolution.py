"""Motor único de evolución causal, independiente de la profundidad fractal.

La memoria almacena restricciones inmutables observadas, no alias a celdas mutables.
Una cola de eventos TriGate es solamente el simulador temporal de Python.
"""
from dataclasses import dataclass, field
from collections import defaultdict
from .atom import Network
from .paths import locally_closed


@dataclass
class Continuation:
    name: str
    evidence: tuple  # (cara, índice, trit): evidencia del tensor observado
    uses: int = 0
    last: int = 0


class Experience:
    def __init__(self):
        self.graph = defaultdict(dict)
        self.clock = 0

    def receive(self, path, tensor):
        path = tuple(path)
        if not path or len(path) > len(tensor.faces):
            raise ValueError('camino inválido')
        for depth, token in enumerate(path):
            pattern = tuple((depth, j, c.value) for j,c in enumerate(tensor.faces[depth]) if c.value != 2)
            prefix = path[:depth]
            old = self.graph[prefix].get(token)
            if old is None:
                self.graph[prefix][token] = Continuation(token, pattern)
            elif old.evidence != pattern:
                # Una misma arista puede recibir evidencia diferente: no sustituimos
                # arbitrariamente el testigo histórico. Su compatibilidad requiere
                # una arista distinta o una representación futura con alternativas.
                raise ValueError('arista observada con evidencia distinta')

    def choices(self, prefix):
        return sorted(self.graph.get(tuple(prefix), {}).values(),
                      key=lambda e: (-e.uses, -e.last, e.name))

    def learn(self, path):
        path = tuple(path)
        for depth, token in enumerate(path):
            edge = self.graph[path[:depth]][token]
            self.clock += 1
            edge.uses += 1
            edge.last = self.clock


class Evolution:
    """Un único motor para átomos de todos los niveles; no hay fases bottom-up.

    `goal` identifica una unidad cuyas caras queremos cristalizar. No cambia
    la ley ni bloquea la resolución de otras unidades, que evolucionan en red.
    """
    def __init__(self, root, experience=None):
        self.root = root
        self.units = tuple(root.walk())
        self.net = root.network()
        self.experience = experience if experience is not None else Experience()
        self.cells = {c for a in self.net.atoms for c in a.cells}

    def snapshot(self):
        return {c:c.value for c in self.cells}

    def restore(self, state):
        for c,v in state.items(): c.value = v
        self.net = self.root.network()

    def input(self, tensor, path=(), constraints=()):
        """La llegada de un tensor abre únicamente sus aristas observadas.

        `constraints` aplica evidencia a celdas compartidas de la red actual.
        """
        if path:
            self.experience.receive(path, tensor)
        if constraints:
            self.net.apply(constraints)
        else:
            self.net.propagate()

    def settle(self, goal, budget=1000, max_depth=3):
        if goal not in self.units:
            raise ValueError('unidad fuera de la red')
        base = self.snapshot()
        visited = 0
        deferred = False
        try:
            self.net.propagate(budget)
        except (ValueError, RuntimeError):
            self.restore(base)
            return {'status':'conflict','attempts':0,'path':()}

        def explore(prefix):
            nonlocal visited, deferred
            if locally_closed(goal):
                return prefix
            if len(prefix) >= max_depth:
                return None
            for edge in self.experience.choices(prefix):
                if visited >= budget:
                    deferred = True
                    return None
                visited += 1
                before = self.snapshot()
                try:
                    self.net.apply([(goal.faces[f][j], v) for f,j,v in edge.evidence], budget)
                    choice = explore(prefix + (edge.name,))
                    if choice is not None:
                        return choice
                except (ValueError, RuntimeError):
                    pass
                self.restore(before)
            return None

        path = explore(())
        if path is None:
            self.restore(base)
            # No hay camino elegible: inviable, independientemente de E abierto.
            # Si existe exploración aplazada y E=2, hay Carry.
            status = ('carry' if deferred and any(g.e.value==2 for g in goal.gates)
                      else 'inviable')
            return {'status':status,'attempts':visited,'path':()}
        self.experience.learn(path)
        return {'status':'local_closed','attempts':visited,'path':path,
                'faces':goal.state,'other_states':tuple(u.state for u in self.units)}
