"""Adapted from Aurora-Program/CORPUS-FPGA reference/trigate.py (Apache-2.0)."""
from dataclasses import dataclass
from itertools import product
WAIT, CHANGED, CLOSED, CONFLICT = range(4)
STATUS_NAMES = ('wait','changed','closed','conflict')

def majority(a,b,m):
    base=(a,b,m)
    return next((v for v in (0,1) if base.count(v)>=2),2)

@dataclass(frozen=True)
class Resolution:
    values: tuple
    status: int
    areas: int
    support: int
    needs_base_refinement: bool=False
    @property
    def direct(self):
        return self.status==CLOSED and self.values[4]==0

def solve(a,b,m,r,e,allowed=255):
    original=(a,b,m,r,e)
    if any(type(v) is not int or v not in (0,1,2) for v in original):
        raise ValueError('invalid trit')
    if type(allowed) is not int or not 0<=allowed<=255:
        raise ValueError('invalid allowed mask')
    base_open=original[:3].count(2)>=2
    n=int(base_open)+int(r==2)+int(e==2)
    candidates=[]
    for av,bv,mv in product((0,1),repeat=3):
        index=av*4+bv*2+mv
        if not allowed & (1<<index): continue
        if any(g!=2 and g!=v for g,v in zip(original[:3],(av,bv,mv))): continue
        if r!=2 and e!=2 and majority(av,bv,mv)^e!=r: continue
        candidates.append((av,bv,mv))
    support=sum(1<<(x*4+y*2+z) for x,y,z in candidates)
    if not candidates: return Resolution(original,CONFLICT,n,0)
    if n>=2: return Resolution(original,WAIT,n,support)
    d=majority(a,b,m)
    updated=list(original)
    if n==0:
        if d==2: return Resolution(original,WAIT,n,support,True)
        return Resolution(original,CLOSED,n,support)
    if base_open:
        for pos in range(3):
            choices={c[pos] for c in candidates}
            if updated[pos]==2 and len(choices)==1: updated[pos]=next(iter(choices))
    elif r==2 and d!=2: updated[3]=d^e
    elif e==2 and d!=2: updated[4]=d^r
    values=tuple(updated)
    return Resolution(values,CHANGED if values!=original else WAIT,n,support)
