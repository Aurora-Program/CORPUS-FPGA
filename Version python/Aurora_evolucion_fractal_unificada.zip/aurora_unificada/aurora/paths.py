"""Memoria contextual + evolución del mismo tensor por eventos TriGate.

La entrada habilita aristas observadas; el cierre legítimo aumenta prioridad.
No hay aristas hipotéticas. Sin salida: rama inviable; E=2: Carry.
"""
from collections import defaultdict
from dataclasses import dataclass
from .atom import Network
from .trigate import solve, CLOSED


@dataclass(eq=False)
class Edge:
    token: str
    links: tuple  # (face, index, Cell) del tensor que realmente usó la arista
    uses: int = 0
    last: int = 0

    def evidence(self):
        # El testigo guarda identidad de celda. Nunca imponemos un trit abierto.
        return [(f, j, c.value) for f, j, c in self.links if c.value != 2]


class Memory:
    def __init__(self):
        self.edges = defaultdict(dict)
        self.clock = 0

    def receive(self, path, tensor):
        """Un tensor entrante habilita SOLO las aristas que ha recorrido.

        `path` es la trayectoria observada de ese tensor (no adivinada).
        Un tensor parcial puede habilitar una trayectoria parcial. Una arista
        reutilizada añade nuevo testigo; no se cambia el origen de la anterior.
        """
        path = tuple(path)
        if not path or len(path) > len(tensor.faces):
            raise ValueError('trayectoria no corresponde a las caras del tensor')
        for i, token in enumerate(path):
            key = path[:i]
            # El primer testigo establece la relación de celdas; usos posteriores
            # sólo confirman su existencia. No cuentan como Output legitimado.
            if token not in self.edges[key]:
                self.edges[key][token] = Edge(token, tuple((i, j, tensor.faces[i][j]) for j in range(3)))

    def observe(self, path, witness):
        """Compatibilidad: experiencia histórica con cierre local probado."""
        if not locally_closed(witness):
            raise ValueError('testigo sin cierre local')
        self.receive(path, witness)
        self.reinforce(path)

    def options(self, prefix):
        return sorted(self.edges.get(tuple(prefix), {}).values(),
                      key=lambda edge: (-edge.uses, -edge.last, edge.token))

    def reinforce(self, path):
        # Sólo tras un Output aceptado; preserva recencia del camino completo.
        for i, token in enumerate(path):
            edge = self.edges[tuple(path[:i])][token]
            self.clock += 1
            edge.uses += 1
            edge.last = self.clock


def locally_closed(unit):
    for g in unit.gates:
        result = solve(*(c.value for c in g.cells), allowed=g.allowed)
        if result.status != CLOSED or g.e.value != 0 or g.r.value == 2:
            return False
    return all(c.value != 2 for face in unit.faces for c in face)


def has_carry(unit):
    return any(g.e.value == 2 for g in unit.gates)


def evolve(root, target, memory, max_depth=3, max_attempts=1000):
    """Itera rutas por prioridad, con rollback y propagación asíncrona.

    `inviable`: todas las continuaciones habilitadas terminan sin salida.
    `carry`: una relación conserva E=2 con exploración aún pendiente (límite).
    `local_closed`: cierre local; NO certificado externo de Aurora.
    """
    units = tuple(root.walk())
    if target not in units:
        raise ValueError('unidad fuera de la pirámide')
    atoms = tuple(g for unit in units for g in unit.gates)
    cells = {c for g in atoms for c in g.cells}
    original = {c: c.value for c in cells}
    attempts = 0
    deferred = False

    def restore(state):
        for cell, value in state.items():
            cell.value = value

    def visit(prefix):
        nonlocal attempts, deferred
        if locally_closed(target):
            return prefix
        if len(prefix) >= max_depth:
            return None
        options = memory.options(prefix)
        for edge in options:
            if attempts >= max_attempts:
                deferred = True
                return None
            attempts += 1
            snapshot = {cell: cell.value for cell in cells}
            try:
                Network(atoms).apply([(target.faces[f][j], v)
                                      for f, j, v in edge.evidence()])
                chosen = visit(prefix + (edge.token,))
                if chosen is not None:
                    return chosen
            except (ValueError, RuntimeError):
                pass
            restore(snapshot)
        # Sin nuevas aristas: rama inviable, aunque algunas E permanezcan abiertas.
        return None

    try:
        Network(atoms).propagate()
        path = visit(())
        if path is not None:
            # Un camino completo y localmente coherente es evidencia, pero
            # aprender globalmente requiere verificación externa posterior.
            memory.reinforce(path)
            return {'status': 'local_closed', 'path': path,
                    'attempts': attempts, 'faces': target.state}
        restore(original)
        return {'status': 'carry' if deferred and has_carry(target) else 'inviable',
                'path': (), 'attempts': attempts}
    except (ValueError, RuntimeError):
        restore(original)
        return {'status': 'conflict', 'path': (), 'attempts': attempts}
