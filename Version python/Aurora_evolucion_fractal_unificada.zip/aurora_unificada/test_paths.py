import unittest
from aurora.fractal import Unit
from aurora.atom import Network
from aurora.paths import Memory, evolve, locally_closed


def witness():
    u = Unit.leaf()
    Network(u.gates).apply([(g.i, 1) for g in u.gates] +
                           [(g.k, 1) for g in u.gates] +
                           [(g.o, 1) for g in u.gates] +
                           [(g.r, 1) for g in u.gates] +
                           [(g.e, 0) for g in u.gates])
    return u


def setup():
    root = Unit.grow(1)
    target = root.children[0]
    root.network().apply([(g.i, 1) for g in target.gates] +
                         [(g.k, 1) for g in target.gates])
    return root, target


class MemoryAsFirstConstraint(unittest.TestCase):
    def test_unobserved_edges_are_impossible(self):
        root, target = setup()
        memory = Memory()
        previous = target.state
        result = evolve(root, target, memory)
        self.assertEqual(result['status'], 'inviable')
        self.assertEqual(result['attempts'], 0)
        self.assertEqual(target.state, previous)

    def test_witness_produces_real_usable_path(self):
        root, target = setup()
        memory = Memory()
        memory.observe(('s', 'e', 'o'), witness())
        result = evolve(root, target, memory)
        self.assertEqual(result['status'], 'local_closed')
        self.assertEqual(result['path'], ('s', 'e', 'o'))
        self.assertEqual(target.state, ((1,1,1),(0,0,0),(1,1,1)))
        self.assertEqual(memory.options(())[0].uses, 2)

    def test_no_memory_from_unclosed_tensor(self):
        m = Memory()
        with self.assertRaises(ValueError):
            m.observe(('new',), Unit.leaf())
        self.assertEqual(len(m.options(())), 0)

    def test_only_used_path_reinforced(self):
        m = Memory()
        w = witness()
        m.observe(('ok', 'e', 'o'), w)
        # El segundo camino ha sido observado, pero la primera cara no encaja.
        other = Unit.leaf()
        other.network().apply([(g.i, 0) for g in other.gates] +
                              [(g.k, 0) for g in other.gates] +
                              [(g.o, 0) for g in other.gates] +
                              [(g.r, 0) for g in other.gates] +
                              [(g.e, 0) for g in other.gates])
        m.observe(('bad',), other)
        before = m.edges[()]['bad'].uses
        root, target = setup()
        result = evolve(root, target, m)
        self.assertEqual(result['path'], ('ok', 'e', 'o'))
        self.assertEqual(m.edges[()]['bad'].uses, before)

    def test_input_enables_edges_without_learning(self):
        m = Memory()
        w = witness()
        m.receive(('s', 'e', 'o'), w)
        self.assertEqual(m.options(())[0].uses, 0)
        root, target = setup()
        result = evolve(root, target, m)
        self.assertEqual(result['status'], 'local_closed')
        self.assertEqual(m.options(())[0].uses, 1)

    def test_recency_orders_equal_frequency(self):
        m = Memory()
        w = witness()
        m.receive(('a',), w)
        m.receive(('b',), w)
        self.assertEqual([e.token for e in m.options(())], ['a', 'b'])
        m.reinforce(('a',))
        m.reinforce(('b',))
        self.assertEqual([e.token for e in m.options(())], ['b', 'a'])

    def test_no_exit_inviable_even_with_open_E(self):
        root, target = setup()
        self.assertTrue(any(g.e.value == 2 for g in target.gates))
        self.assertEqual(evolve(root, target, Memory())['status'], 'inviable')

    def test_carry_only_for_pending_branch_with_open_E(self):
        root, target = setup()
        m = Memory()
        m.receive(('s', 'e', 'o'), witness())
        result = evolve(root, target, m, max_attempts=0)
        self.assertEqual(result['status'], 'carry')
        self.assertEqual(m.options(())[0].uses, 0)

    def test_upper_can_close_before_inferior(self):
        root = Unit.grow(1)
        root.network().apply([(g.i, 1) for g in root.gates] +
                             [(g.k, 1) for g in root.gates] +
                             [(g.o, 1) for g in root.gates] +
                             [(g.r, 1) for g in root.gates] +
                             [(g.e, 0) for g in root.gates])
        self.assertTrue(locally_closed(root))
        self.assertTrue(all(not locally_closed(child) for child in root.children))


if __name__ == '__main__': unittest.main()
