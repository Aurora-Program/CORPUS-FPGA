import unittest
from aurora.fractal import Unit
from aurora.evolution import Evolution, Experience
from aurora.atom import Network


def completed():
    u=Unit.leaf()
    Network(u.gates).apply([(g.i,1) for g in u.gates]+[(g.k,1) for g in u.gates]+[(g.o,1) for g in u.gates]+[(g.r,1) for g in u.gates]+[(g.e,0) for g in u.gates])
    return u

class UnifiedEvolution(unittest.TestCase):
    def test_input_enables_but_does_not_learn(self):
        root=Unit.grow(1)
        eng=Evolution(root)
        eng.input(completed(),('a','b','c'))
        self.assertEqual(eng.experience.choices(())[0].uses,0)
        self.assertEqual(len(eng.experience.choices(('a',))),1)
    def test_path_completes_and_learns(self):
        root=Unit.grow(1)
        eng=Evolution(root)
        goal=root.children[0]
        eng.input(completed(),('a','b','c'), [(g.i,1) for g in goal.gates]+[(g.k,1) for g in goal.gates])
        res=eng.settle(goal)
        self.assertEqual(res['status'],'local_closed')
        self.assertEqual(res['path'],('a','b','c'))
        self.assertEqual(eng.experience.choices(())[0].uses,1)
    def test_no_memory_inviable(self):
        root=Unit.grow(1); eng=Evolution(root)
        self.assertEqual(eng.settle(root.children[0])['status'],'inviable')
    def test_budget_carry(self):
        root=Unit.grow(1); eng=Evolution(root)
        eng.input(completed(),('a','b','c'))
        self.assertEqual(eng.settle(root.children[0],budget=0)['status'],'carry')
        self.assertEqual(eng.experience.choices(())[0].uses,0)
    def test_upper_without_lower_closure(self):
        root=Unit.grow(1); eng=Evolution(root)
        eng.net.apply([(g.i,1) for g in root.gates]+[(g.k,1) for g in root.gates]+[(g.o,1) for g in root.gates]+[(g.r,1) for g in root.gates]+[(g.e,0) for g in root.gates])
        from aurora.paths import locally_closed
        self.assertTrue(locally_closed(root))
        self.assertTrue(all(not locally_closed(c) for c in root.children))
    def test_memory_evidence_is_immutable(self):
        m=Experience(); w=completed(); m.receive(('a','b','c'),w)
        recorded=m.choices(())[0].evidence
        for gate in w.gates: gate.r.value=2
        self.assertEqual(m.choices(())[0].evidence,recorded)

if __name__=='__main__': unittest.main()
