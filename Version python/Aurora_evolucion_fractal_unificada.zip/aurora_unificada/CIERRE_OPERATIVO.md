# Cierre operativo del núcleo reducido

Este paquete **no es aún Aurora completa**: demuestra el ciclo local de entrada,
memoria, iteración, encaje y aprendizaje contextual con TriGate compartidos.

## Estados
- `inviable`: no hay arista habilitada que conduzca a cierre (se agotan alternativas).
- `carry`: queda E=2 y la exploración se pospone por un presupuesto de intentos.
- `conflict`: restricciones TriGate incompatibles; transacción revertida.
- `local_closed`: las relaciones locales tienen R concreto, E=0 y caras concretas.

## Flujo
1. `Memory.receive(path, tensor)`: llega un tensor que recorrió ese `path`;
   habilita esas aristas, **sin aumentar prioridad**. Las celdas permanecen
   compartidas con ese tensor; no se crean aristas no observadas.
2. `evolve(root, target, memory)`: propaga eventos; explora opciones por número
   de salidas cerradas y recencia; restaura el estado al fallar una rama;
   reintenta con otra.
3. Un cierre local refuerza el camino realizado. Esto es **aprendizaje local**,
   no prueba de legitimidad de Output externo de Aurora.

## Limitaciones no resueltas
- La trayectoria de un tensor de entrada (`path`) sigue aportándose desde fuera;
  no se deriva automáticamente de todas las relaciones fractales.
- El índice de memoria todavía es un diccionario Python, no átomos recursivos.
- DO todavía está asociado provisionalmente a M, sin semántica completa.
- La ley `solve()` conserva R/E indeterminados si las relaciones no aportan
  evidencia. Un `local_closed` del ejemplo utiliza un testigo ya cerrado;
  **no demuestra** la emergencia autónoma de ese cierre.
- No está implementado el certificado de cierre superior ni la salida global;
  por tanto el proyecto antiguo no se puede sustituir funcionalmente aún.
