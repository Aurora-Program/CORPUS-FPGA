# Aurora: evolución fractal + memoria contextual de caminos

**Implementación experimental y recortada** a partir de `Aurora_emergencia_fractal_recursiva`. Se conserva el TriGate original; la memoria solamente ordena las continuaciones. Las restricciones se aplican a las mismas celdas `Cell` que ya utiliza `Unit` (sin trasladarlas a estructuras de tensor distintas).

## Qué se ha integrado

1. `Unit` compone tres unidades de idéntico tipo y reutiliza sus celdas sin copiarlas. Los niveles superiores vuelven a tener DS, DE y DO.
2. `Network` propaga cambios por dependencias, arriba y abajo, usando el TriGate original.
3. `Paths` recuerda continuaciones según el **prefijo completo**, con prioridad local y sin lista global de tokens.
4. `evolve_path` ensaya restricciones sobre una unidad de cualquier nivel, propaga con `Network`, retrocede ante contradicción o camino incompleto y actualiza prioridades **solo al alcanzar cierre local comprobado**.
5. Un tensor puede volver a participar en la formación de otro nivel, sin conversión I/K/O.

## Demo reproducible

```bash
python demo_paths.py
python -m unittest discover -v
```

El ejemplo parte de dos entradas concretas (`i=k=1`) en cada TriGate de una unidad. La memoria ofrece primero un camino de mayor prioridad incompatible o estéril y después un camino alternativo que completa tres caras: DS=111, DE=000, DO=111. Aprende solo el camino cerrado.

## Lo que esta versión NO demuestra

- El cierre `local_closed` **no** es una certificación del momento de coherencia superior para toda la red de Transcenders ni de un Output externo legítimo.
- DO continúa representado provisionalmente por la tercera entrada del TriGate y no implementa aún todas las reglas de orientación e iteración del libro.
- El recorrido usa backtracking Python acotado; para FPGA deberá adoptar exploración causal distribuida/arbiter con recursos delimitados.
- La memoria `Paths` es una tabla de relaciones con prefijos y prioridades, **no** está todavía materializada como unidades `Unit` del mismo grafo (homoiconicidad estructural del almacenaje pendiente).
- El ejemplo usa reglas de cierre local adicionales (`R concreto`, `E=0`, `solve` cerrado) como criterio de promoción; la semántica completa requiere verificar el cierre superior y la realización externa.

No sustituir aún el repositorio anterior. Esta implementación prueba una integración de **recorrido → restricciones → propagación → cierre local → prioridad**, no la completitud de Aurora.
