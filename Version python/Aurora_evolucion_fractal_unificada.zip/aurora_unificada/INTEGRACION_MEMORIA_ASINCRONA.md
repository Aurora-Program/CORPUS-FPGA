# Aurora: memoria como primera restricción y evolución sin orden de escalas

## Semántica implementada

- `Memory()` empieza vacío: sin tensor testigo usado, **no existe ninguna arista**. Una prioridad cero no crea disponibilidad.
- `Memory.observe(path, witness)` registra exclusivamente un tensor local cerrado, con sus tres caras DS/DE/DO. Los enlaces de memoria referencian las **celdas reales del testigo**; no se almacenan valores de salida previamente inventados.
- La memoria de continuaciones está indexada por el prefijo exacto (camino contextual). La prioridad es el número de usos registrados y reforzados, no una puntuación global del token.
- `evolve()` explora solo aristas observadas, aplica su evidencia a las mismas celdas tensoriales del destino y deja a `Network`/TriGate comprobar todas las restricciones; los fallos revierten sus cambios.
- `Network` resuelve una cola de **celdas afectadas**, sin fases hoja→raíz. Una unidad superior puede cerrarse mientras las inferiores están abiertas, tal como enseña `test_upper_can_close_before_inferior`.

## Cómo reproducir

```bash
python demo_memory.py
python -m unittest discover -v
```

## Alcance y límites

El registro inicial del testigo es un acto observable de uso previo; **no se deduce una memoria no existente**. El aprendizaje al cerrar en este prototipo es local; no implica aún legitimidad de Output externo. Las aristas se guardan en un índice `dict` de Python por eficiencia; sus restricciones referencian celdas tensoriales, pero ese índice todavía **no es un grafo fractal codificado íntegramente en tensores**. `DO` sigue siendo una aproximación provisional por la entrada M del TriGate. `observe` registra como máximo tres caras en un camino; queda pendiente hacerlo fractal sin esa restricción de longitud. La cola de eventos de Python simula causalidad, no temporización física asíncrona del hardware.

La solución no pretende que el cierre de una unidad superior convierta en cerrados sus descendientes: puede existir coherencia local superior con Carries inferiores. Una salida externa requiere criterios adicionales del modelo original.
