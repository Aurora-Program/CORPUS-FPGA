# Aurora — Átomo informacional fractal con memoria observada

Un único `Atom` (TriGate) compone `Unit` de tres caras DS, DE y DO y escala de forma recursiva. Las celdas son compartidas: una relación superior no crea copias de las inferiores.

## Novedad: memoria como restricción previa

`Memory` solo permite aristas cuyo camino haya sido **utilizado por un tensor testigo cerrado**. No existen aristas especulativas. Se explora el grafo por prioridad contextual y solo se refuerza la ruta con cierre local; una ruta incompatible se descarta transaccionalmente.

## Asincronía causal

El simulador `Network` activa únicamente átomos afectados por cambios y no impone que las hojas se resuelvan antes de la cúspide. El test demuestra cierre superior con tres hijos todavía indeterminados.

## Reproducir

```bash
python demo_memory.py
python -m unittest discover -v
```

Para semántica, pruebas y límites, consultar `INTEGRACION_MEMORIA_ASINCRONA.md`.

**Importante**: todavía no hay cierre externo completo de Aurora, ni codificación tensorial del índice de caminos ni toda la semántica original de DO.
